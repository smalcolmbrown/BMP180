/*
BMP180.h - Header file for the BMP180 Barometric Pressure Sensor Arduino Library.
Copyright (C) 2012 Love Electronics Ltd (loveelectronics.com)

extencively re written and bugs fixed by Suusi Malcolm-Brown M0SUU (c) 2013

This program is free software: you can redistribute it and/or modify
it under the terms of the version 3 GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

 Datasheet for BMP180:
 http://www.bosch-sensortec.com/content/language1/downloads/BST-BMP180-DS000-07.pdf

*/

#include "BMP180.h"
#include "Arduino.h"

///////////////////////////////////////////////////////////////////
//
// BMP180() constructor creates the BMP180 class and fills in some defaults
//
///////////////////////////////////////////////////////////////////

BMP180::BMP180()
{
	lSeaLevelPressure = 101325 ;	// set to 1013.25 milli Barr as default

	LastTemperatureTime = -1000;
	LastTemperatureData = 0;

	AcceptableTemperatureLatencyForPressure = 1000;

	SetResolution(BMP180_MODE_STANDARD);
}

///////////////////////////////////////////////////////////////////
//
// SetSeaLevelPressure( long lNewSeaLevelPressure )
//
// Sets lSeaLevelPressure to lNewSeaLevelPressure
//
// returns nothing
//
///////////////////////////////////////////////////////////////////

void BMP180::SetSeaLevelPressure( long lNewSeaLevelPressure )
{
	lSeaLevelPressure = lNewSeaLevelPressure ;
}

///////////////////////////////////////////////////////////////////
//
// SetSeaLevelPressure( BMP180_HEIGHT_t iUnits, float fAltitude )
//
// Sets lSeaLevelPressure to the value calculated from fAltitude
// in meters and current atmospheric pressure in pascals
//
// returns lSeaLevelPressure 
//
///////////////////////////////////////////////////////////////////

long BMP180::SetSeaLevelPressure( BMP180_HEIGHT_t iUnits, float fAltitude )
{
	long lPressure = GetPressure();					// get the current pressure
	fAltitude = (iUnits) ? ( fAltitude / 3.2808399 ) : fAltitude ;		// if in feet convert to meters
	lSeaLevelPressure = lPressure / pow( ( 1.0 - ( fAltitude / 44330.0 )), 5.25) ;
#ifdef BMP180_DEBUG
	Serial.print( "\nPressure = " ) ;
	Serial.print( lPressure ) ;
	Serial.print( "\tAltitude = " ) ;
	Serial.print( fAltitude) ; 
	Serial.print( "\tNew sea level presure = " ) ;
	Serial.println( lSeaLevelPressure ) ;
#endif
	return lSeaLevelPressure ;
}


///////////////////////////////////////////////////////////////////
//
// SetSeaLevelPressure( BMP180_HEIGHT_t iUnits, float fAltitude, long lPressure )
//
// Sets lSeaLevelPressure to the value calculated from fAltitude
// in meters and lPressure in pascals
//
// returns lSeaLevelPressure 
//
///////////////////////////////////////////////////////////////////


long BMP180::SetSeaLevelPressure( BMP180_HEIGHT_t iUnits, float fAltitude, long lPressure)
{
	fAltitude = (iUnits) ? ( fAltitude / 3.2808399 ) : fAltitude ;		// if in feet convert to meters
	lSeaLevelPressure = lPressure / pow( ( 1 - ( fAltitude / 44330 )), 5.25) ;
#ifdef BMP180_DEBUG
	Serial.print( "\nPressure = " ) ;
	Serial.print( lPressure ) ;
	Serial.print( "\tAltitude = " ) ;
	Serial.print( fAltitude) ; 
	Serial.print( "\tNew sea level presure = " ) ;
	Serial.println( lSeaLevelPressure ) ;
#endif
	return lSeaLevelPressure ;
}

///////////////////////////////////////////////////////////////////
//
// Initialize(void)
//
// copies calibration data from BMP180 device to the BMP180 class
//
// returns nothing
//
///////////////////////////////////////////////////////////////////

void BMP180::Initialize(void)
{
	uint8_t* buffer = Read(BMP180_CALIBRATION_START_REGISTER, BMP180_CALIBRATION_END_REGISTER - BMP180_CALIBRATION_START_REGISTER + 2);
	// This data is in Big Endian format from the BMP180.
	Calibration_AC1 = (buffer[0]  << 8) | buffer[1];
	Calibration_AC2 = (buffer[2]  << 8) | buffer[3];
	Calibration_AC3 = (buffer[4]  << 8) | buffer[5];
	Calibration_AC4 = (buffer[6]  << 8) | buffer[7];
	Calibration_AC5 = (buffer[8]  << 8) | buffer[9];
	Calibration_AC6 = (buffer[10] << 8) | buffer[11];
	Calibration_B1  = (buffer[12] << 8) | buffer[13];
	Calibration_B2  = (buffer[14] << 8) | buffer[15];
	Calibration_MB  = (buffer[16] << 8) | buffer[17];
	Calibration_MC  = (buffer[18] << 8) | buffer[19];
	Calibration_MD  = (buffer[20] << 8) | buffer[21];
}

#ifdef BMP180_DEBUG
///////////////////////////////////////////////////////////////////
//
// PrintCalibrationData(void)
//
// this function is only included if BMP180_DEBUG is defined in
// script
//
// Returns Nothing
//
///////////////////////////////////////////////////////////////////

void BMP180::PrintCalibrationData(void)
{
	Serial.print("AC1:\t"); Serial.println(Calibration_AC1);
	Serial.print("AC2:\t"); Serial.println(Calibration_AC2);
	Serial.print("AC3:\t"); Serial.println(Calibration_AC3);
	Serial.print("AC4:\t"); Serial.println(Calibration_AC4);
	Serial.print("AC5:\t"); Serial.println(Calibration_AC5);
	Serial.print("AC6:\t"); Serial.println(Calibration_AC6);
	Serial.print("B1:\t"); Serial.println(Calibration_B1);
	Serial.print("B2:\t"); Serial.println(Calibration_B2);
	Serial.print("MB:\t"); Serial.println(Calibration_MB);
	Serial.print("MC:\t"); Serial.println(Calibration_MC);
	Serial.print("MD:\t"); Serial.println(Calibration_MD);
}
#endif


///////////////////////////////////////////////////////////////////
//
// SoftReset(void)
//
// forces the BMP180 device to do a soft reset
//
// Returns Nothing
//
///////////////////////////////////////////////////////////////////

void BMP180::SoftReset(void)
{	Write(BMP180_SOFT_RESET_REGISTER, BMP180_SOFT_RESET_INSTRUCTION);
	delay(100);
}



///////////////////////////////////////////////////////////////////
//
// GetSeaLevelPressure(void)
//
// Returns: lSeaLevelPressure
//
///////////////////////////////////////////////////////////////////

long BMP180::GetSeaLevelPressure(void) 
{
	return lSeaLevelPressure;
}

///////////////////////////////////////////////////////////////////
//
// IsConnected()
//
// NOTE not compatible with error codes
//
// returns: true if BMP180 is connected otherwise false if not
//
///////////////////////////////////////////////////////////////////

bool BMP180::IsConnected(void)
{
	uint8_t *data = Read(BMP180_CHIP_ID_REGISTER, 1);
	return (*(data) == BMP180_CHIP_ID ) ?  true : false;
}

///////////////////////////////////////////////////////////////////
//
// SetResolution(BMP180_MODES_t iNewSampleMode )
//
// Sets the wait time and the number of samples depending on the
// sample mode. Note advanced mode is not supported. 
//
// returns: BMP180_ERROR_NONE if sample mode is OK otherwise 
//          BMP180_ERROR_SAMPLE_MODE_NOT_VALID if not
//
///////////////////////////////////////////////////////////////////

BMP180_ERRORS_t BMP180::SetResolution(BMP180_MODES_t iNewSampleMode )
{
	switch (iNewSampleMode ) {
		case BMP180_MODE_ULTRA_LOW_POWER:
			iWaitTime = BMP180_WAIT_5MS ;
			iSamples = BMP180_SAMPLES_1 ;
			break;
        	case BMP180_MODE_STANDARD:
			iWaitTime = BMP180_WAIT_8MS ;
			iSamples = BMP180_SAMPLES_2 ;
			break;
        	case BMP180_MODE_HIGH_RESOLUTION:
			iWaitTime = BMP180_WAIT_14MS ;
			iSamples = BMP180_SAMPLES_4 ;
			break;
		case BMP180_MODE_ULTRA_HIGH_RESOLUTION:
			iWaitTime = BMP180_WAIT_26MS ;
			iSamples = BMP180_SAMPLES_8 ;
			break;
        	default:
			return BMP180_ERROR_SAMPLE_MODE_NOT_VALID ;
	}
	// if we get here sampleResolution is OK

    	iSampleMode = iNewSampleMode;			// save iNewSampleMode
	return BMP180_ERROR_NONE;			// success
}

///////////////////////////////////////////////////////////////////
//
// GetUncompensatedTemperature(void)
//
// gets the raw temperature data from the registers.
//
// returns: the raw temperature value
//
///////////////////////////////////////////////////////////////////

int BMP180::GetUncompensatedTemperature(void)
{
	// Instruct device to perform a conversion.
	Write(BMP180_MEASUREMENT_CONTROL_REGISTER, BMP180_MEASURE_TEMPERATURE);
	// Wait for the conversion to complete.
	delay(5);
	uint8_t* data = Read(BMP180_OutMSB, 2);
	int value = (data[0] << 8) | data[1];
	return value;
}


///////////////////////////////////////////////////////////////////
//
// GetUncompensatedPressure(void)
//
// gets the raw pressure data from the registers.
//
// returns: the raw Pressure value
//
///////////////////////////////////////////////////////////////////


long BMP180::GetUncompensatedPressure(void)
{
	long pressure = 0;
	int loops = iSamples;

	// Instruct device to perform a conversion, including the oversampling data.
        uint8_t CtrlByte = BMP180_MEASURE_PRESSURE + (iSampleMode << 6);

	Write(BMP180_MEASUREMENT_CONTROL_REGISTER, CtrlByte);
		
	// Wait for the conversion
	delay(iWaitTime);		

	uint8_t buffer[3];
	// Read the conversion data into buffer.
	Read(BMP180_OutMSB, 3, buffer);

        // Collect the data (and push back the LSB if we are not sampling them).
        pressure = ((((long)buffer[0] <<16) | ((long)buffer[1] <<8) | ((long)buffer[2])) >> (8-iSampleMode));
	return pressure ;
}

///////////////////////////////////////////////////////////////////
//
// CompensateTemperature(int iUncompensatedTemperature)
//
// gets the actual temperature from the uncompensatedTemperature.
//
// returns: the actual temperature value
//
///////////////////////////////////////////////////////////////////

float BMP180::CompensateTemperature(int iUncompensatedTemperature)
{
    int iTemperature;
    int x2;
	long x1;
	x1 = (((long)iUncompensatedTemperature - (long)Calibration_AC6) * (long)Calibration_AC5) >> 15;
    x2 = ((long)Calibration_MC << 11) / (x1 + Calibration_MD);
    int param_b5 = x1 + x2;
    iTemperature = (int)((param_b5 + 8) >> 4);  /* temperature in 0.1 deg C*/
    float fTemperature = iTemperature;
	fTemperature /= 10.0;

    // Record this data because it is required by the pressure algorithem.
    LastTemperatureData = param_b5;
    LastTemperatureTime = millis();

    return fTemperature;
}

///////////////////////////////////////////////////////////////////
//
// CompensatePressure(long lUncompensatedPressure)
//
// gets the actual Pressure from the lUncompensatedPressure.
//
// returns: the actual Pressure value
//
///////////////////////////////////////////////////////////////////

long BMP180::CompensatePressure(long lUncompensatedPressure)
{
	int msSinceLastTempReading = millis() - LastTemperatureTime;
	// Check to see if we have old temperature data.

	if (msSinceLastTempReading > AcceptableTemperatureLatencyForPressure) {
		GetTemperature(BMP180_CENTIGRADE); // Refresh the temperature.
	}
#ifdef BMP180_DEBUG
	// Data from the BMP180 datasheet to test algorithm.
	iSampleMode = 0;
	lUncompensatedPressure = 23843;
	LastTemperatureData = 2399;
	Calibration_AC1 = 408;
	Calibration_AC2 = -72;
	Calibration_AC3 = -14383;
	Calibration_AC4 = 32741;
	Calibration_AC5 = 32757;
	Calibration_AC6 = 23153;
	Calibration_B1  = 6190;
	Calibration_B2  = 4;
	Calibration_MB  = -32767;
	Calibration_MC  = -8711;
	Calibration_MD  = 2868;
#endif

	// Algorithm taken from BMP180 datasheet.
	long b6 = LastTemperatureData - 4000;
	long x1 = (Calibration_B2 * (b6 * b6 >> 12)) >> 11;
	long x2 = Calibration_AC2 * b6 >> 11;
	long x3 = x1 + x2;
	long b3 = ((Calibration_AC1 * 4 + x3) << iSampleMode) + 2;
	b3 = b3 >> 2;
	x1 = Calibration_AC3 * b6 >> 13;
	x2 = (Calibration_B1 * (b6 * b6 >> 12)) >> 16;
	x3 = ((x1 + x2) + 2) >> 2;
	unsigned long b4 = Calibration_AC4 * (x3 + 32768) >> 15;
	unsigned long b7 = (((lUncompensatedPressure - b3)) * (50000 >> iSampleMode));
	long lPressure ;
	if ( b7 < 0x80000000 ) {
		lPressure =  ((b7 * 2) / b4) ;
	} else {
		lPressure =  ((b7 / b4) * 2) ;
	}
	x1 = (lPressure >> 8) * (lPressure >> 8);
	x1 = (x1 * 3038) >> 16;
	x2 = (-7357 * lPressure) >> 16;
	lPressure = lPressure + ((x1 + x2 + 3791) >> 4);

	return lPressure;
}

///////////////////////////////////////////////////////////////////
//
// GetTemperature(BMP180_TEMPERATURE_t iUnits)
//
// gets the actual temperature.
//
// returns: if iUnits == BMP180_CENTIGRADE the temperature in degrees C
//          if iUnits == BMP180_FAHRENHEIT the temperature in degrees F
//
///////////////////////////////////////////////////////////////////

float BMP180::GetTemperature(BMP180_TEMPERATURE_t iUnits)
{
	return (iUnits) ? (((CompensateTemperature(GetUncompensatedTemperature())*9)/5)+32) : CompensateTemperature(GetUncompensatedTemperature());
}

///////////////////////////////////////////////////////////////////
//
// GetPressure(void)
//
// gets the actual Pressure.
//
// returns: the actual Pressure value in pascals
//
///////////////////////////////////////////////////////////////////

long BMP180::GetPressure(void)
{
	return CompensatePressure(GetUncompensatedPressure());
}

///////////////////////////////////////////////////////////////////
//
// GetAltitude(BMP180_HEIGHT_t iUnits)
//
// calculates the altitude from fPressure and lSeaLevelPressure in meters
// or feet depending on iUnits.
//
// returns: if iUnits == BMP180_METERS the altitude in Meters
//          if iUnits == BMP180_FEET the altitude in feet
//
///////////////////////////////////////////////////////////////////

float BMP180::GetAltitude(BMP180_HEIGHT_t iUnits)
{
    // Get pressure in Pascals (Pa).
    float fPressure = GetPressure();
    // Calculate altitude from sea level.
    float fAltitude = 44330.0 * (1.0 - pow( fPressure / lSeaLevelPressure, 0.1902949571836346));
    return (iUnits) ? ( fAltitude * 3.2808399 ) : fAltitude ;
}

///////////////////////////////////////////////////////////////////
//
// GetAltitude(BMP180_HEIGHT_t iUnits, long lCurrentSeaLevelPressureInPa)
//
// calculates the altitude from fPressure and lCurrentSeaLevelPressureInPa 
// in meters or feet depending on iUnits.
//
// returns: if iUnits == BMP180_METERS the altitude in Meters
//          if iUnits == BMP180_FEET the altitude in feet
//
///////////////////////////////////////////////////////////////////

float BMP180::GetAltitude(BMP180_HEIGHT_t iUnits, long lCurrentSeaLevelPressureInPa)
{
	// Get pressure in Pascals (Pa).
	float fPressure = GetPressure();
	// Calculate altitude from sea level.
	float fAltitude = 44330.0 * (1.0 - pow( fPressure / lCurrentSeaLevelPressureInPa, 0.1902949571836346));
	return (iUnits) ? ( fAltitude * 3.2808399 ) : fAltitude ;
}

///////////////////////////////////////////////////////////////////
//
// GetErrorText(BMP180_ERRORS_t iErrorCode )
//
// displays error messages depending on iErrorCode 
//
// returns: char* to error message
//
///////////////////////////////////////////////////////////////////

char* BMP180::GetErrorText(BMP180_ERRORS_t iErrorCode )
{
	switch(iErrorCode  ) {
		case BMP180_ERROR_NONE:
			return "No Error found" ;
			break;
		case BMP180_ERROR_SAMPLE_MODE_NOT_VALID:
			return "Sample Mode was not valid, valid values are: ultra low power = 0, standard = 1, high resolution = 2, ultra high resolution = 3" ;
			break;
		case BMP180_ERROR_BMP180_NOT_CONNECTED:
			return "BMP180 Not Connected" ;
			break;
		default:
			return "Error not defined.";
			break;
	}
}

///////////////////////////////////////////////////////////////////
//
// protected functions
//
///////////////////////////////////////////////////////////////////
//
// Write(int iAddress, int iData)
//
// sends data idata to BMP180 device iAddress over i^2 buss
//
// returns: nothing
//
///////////////////////////////////////////////////////////////////

void BMP180::Write(int iAddress, int iData)
{
	Wire.beginTransmission(BMP180_ADDRESS);
	Wire.write(iAddress);
	Wire.write(iData);
	Wire.endTransmission();
}

///////////////////////////////////////////////////////////////////
//
// Read(int address, int length)
//
// reads idata from BMP180 device iAddress and sucessive addresses 
// over i^2 buss
//
// returns: uint8_t* to data
//
///////////////////////////////////////////////////////////////////

uint8_t* BMP180::Read(int address, int length)
{
  Wire.beginTransmission(BMP180_ADDRESS);
  Wire.write(address);
  Wire.endTransmission();
  
  Wire.beginTransmission(BMP180_ADDRESS);
  Wire.requestFrom(BMP180_ADDRESS, length);

  uint8_t buffer[length];
  while(Wire.available()) {
	  for(uint8_t i = 0; i < length; i++) {
		  buffer[i] = Wire.read();
	  }
  }

  Wire.endTransmission();

  return buffer;
}

///////////////////////////////////////////////////////////////////
//
// Read(int address, int length, uint8_t buffer[])
//
// reads idata from BMP180 device iAddress and length sucessive 
// addresses over i^2 buss into the address pointed to by buffer
//
// returns: nothing
//
///////////////////////////////////////////////////////////////////

void BMP180::Read(int address, int length, uint8_t buffer[])
{
  Wire.beginTransmission(BMP180_ADDRESS);
  Wire.write(address);
  Wire.endTransmission();
  
  Wire.beginTransmission(BMP180_ADDRESS);
  Wire.requestFrom(BMP180_ADDRESS, length);

  while(Wire.available()) {
	  for(uint8_t i = 0; i < length; i++) {
		  buffer[i] = Wire.read();
	  }
  }

  Wire.endTransmission();
}

///////////////////////////////////////////// end of BMP180.cpp ////////////////////