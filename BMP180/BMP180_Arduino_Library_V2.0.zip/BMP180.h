/*
BMP180.h - Header file for the BMP180 Barometric Pressure Sensor Arduino Library.
Copyright (C) 2012 Love Electronics Ltd (loveelectronics.com)

extencively re written and bugs fixed by Suusi Malcolm-Brown M0SUU (c) 2013

This program is free software: you can redistribute it and/or modify
it under the terms of the version 3 GNU General Public License as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

 Datasheet for BMP180:
 http://www.bosch-sensortec.com/content/language1/downloads/BST-BMP180-DS000-07.pdf

*/

#ifndef BMP180_h
#define BMP180_h

#include <inttypes.h>
#include "../Wire/Wire.h"

#define BMP180_ADDRESS                      0x77
#define BMP180_CHIP_ID_REGISTER             0xD0
#define BMP180_CHIP_ID                      0x55
#define BMP180_SOFT_RESET_REGISTER          0xE0
#define BMP180_SOFT_RESET_INSTRUCTION       0xB6		// power on reset
#define BMP180_MEASURE_TEMPERATURE          0x2E
#define BMP180_MEASURE_PRESSURE             0x34
#define BMP180_CALIBRATION_START_REGISTER   0xAA
#define BMP180_CALIBRATION_END_REGISTER     0xBE
#define BMP180_MEASUREMENT_CONTROL_REGISTER 0xF4
#define BMP180_OutMSB                       0xF6		// a/d converter out MSD
#define BMP180_OutLSB                       0xF7		// a/d converter out LSD
#define BMP180_OutXLSB                      0xF8		// a/d converter out XLSD

enum BMP180_TEMPERATURE_t {	BMP180_CENTIGRADE = 0,
				BMP180_FAHRENHEIT };

enum BMP180_HEIGHT_t	{	BMP180_METERS = 0,
				BMP180_FEET };

enum BMP180_SAMPLES_t	{	BMP180_SAMPLES_1 = 1,
				BMP180_SAMPLES_2 = 2,
				BMP180_SAMPLES_4 = 4,
				BMP180_SAMPLES_8 = 8  } ;

enum BMP180_WAIT_t	{	BMP180_WAIT_5MS  =  5,
				BMP180_WAIT_8MS  =  8,
				BMP180_WAIT_14MS = 14,
				BMP180_WAIT_26MS = 26  } ;

enum BMP180_MODES_t	{	BMP180_MODE_ULTRA_LOW_POWER = 0, 
				BMP180_MODE_STANDARD, 
				BMP180_MODE_HIGH_RESOLUTION, 
				BMP180_MODE_ULTRA_HIGH_RESOLUTION };

enum BMP180_ERRORS_t	{	BMP180_ERROR_NONE = 0, 
                          	BMP180_ERROR_SAMPLE_MODE_NOT_VALID, 
				BMP180_ERROR_BMP180_NOT_CONNECTED } ;


class BMP180
{
	public:
	  BMP180() ;

	  void Initialize(void);
#ifdef BMP180_DEBUG
	  void                  PrintCalibrationData(void);
#endif
	  void            SoftReset(void);
	  bool            IsConnected(void);
	  BMP180_ERRORS_t SetResolution(BMP180_MODES_t iNewOverSample);

	  int             GetUncompensatedTemperature(void);
	  long            GetUncompensatedPressure(void);

	  float           CompensateTemperature(int iUncompensatedTemperature);
	  long            CompensatePressure(long iUncompensatedPressure);
	  
	  float           GetTemperature(BMP180_TEMPERATURE_t iUnits);
	  long            GetPressure(void);

	  void            SetSeaLevelPressure(long lNewSeaLevelPressure );
	  long            SetSeaLevelPressure(BMP180_HEIGHT_t iUnits, float fAltitude) ;
	  long            SetSeaLevelPressure(BMP180_HEIGHT_t iUnits, float fAltitude, long lPressure) ;
	  long	          GetSeaLevelPressure(void);

	  float           GetAltitude(BMP180_HEIGHT_t iUnits);
	  float           GetAltitude(BMP180_HEIGHT_t iUnits, long lCurrentSeaLevelPressureInPa);
	  
	  char*           GetErrorText(BMP180_ERRORS_t errorCode);

	protected:
		void     Write(int address, int byte);
		uint8_t* Read(int address, int length);
		void     Read(int address, int length, uint8_t buffer[]);

	private:
		long  				lSeaLevelPressure ;	// stores the current sea level pressure in Pa (default 101325 pa)
        	BMP180_MODES_t 			iSampleMode;		// sample mode (OSS from data sheet)
		BMP180_SAMPLES_t                iSamples;		// number of samples taken depending on iSampleMode
		BMP180_WAIT_t                   iWaitTime;		// conversion time taken depending on iSampleMode
		int LastTemperatureData;
		int LastTemperatureTime;
		int AcceptableTemperatureLatencyForPressure;
		
		int Calibration_AC1;
        	int Calibration_AC2;
        	int Calibration_AC3;
        	unsigned int Calibration_AC4;
        	unsigned int Calibration_AC5;
        	unsigned int Calibration_AC6;
        	int Calibration_B1;
        	int Calibration_B2;
        	int Calibration_MB;
        	int Calibration_MC;
        	int Calibration_MD;
};
#endif